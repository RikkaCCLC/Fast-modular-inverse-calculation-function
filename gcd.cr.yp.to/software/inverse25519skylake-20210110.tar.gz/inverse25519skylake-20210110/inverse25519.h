#ifndef inverse25519_h
#define inverse25519_h

#define inverse25519 inverse25519_skylake

void inverse25519(unsigned char *,const unsigned char *);

#endif
